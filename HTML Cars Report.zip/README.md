A bare minimum [HTML](https://en.wikipedia.org/wiki/HTML) page.

See also [React Starter](https://beta.vizhub.com/curran/c3b14112dae34ef395999cef5783324f).